
public class metToImp {

	/** Method used for calculating kilometres to miles conversion
	 * @param distance of type double 
	 * @return calculated distance
	 */
	public double kilomToMiles(double distance) {
		return distance * 0.621371;
	}
	
	/** Method used for calculating metres to yards
	 * @param distance of type double
	 * @return calculated distance
	 */
	public double metresToYard(double distance) {
		return distance * 1.09361;
	}
	
	/** Method used for calculating metres to feet
	 * @param distance of type double
	 * @return calculated distance
	 */
	public double metresToFeet(double distance) {
		return distance * 3.28084;
	}
	
	/** Method used for calculating kilograms to pounds
	 * @param weight of type double
	 * @return calculated weight
	 */
	public double kilogToPounds(double weight) {
		return weight * 2.20462;
	}
	
	/** Method used for calculating tonnes to tons
	 * @param weight of type double
	 * @return calculated weight
	 */
	public double tonneToTon(double weight) {
		return weight * 1.10231;
	}
	/** Method used for calculating centimetres to feet and inches
	 * @param distance of type double
	 * @return calculated distance
	 */
	public String centToFeetandInche(double distance) {
		distance = distance / 2.54;
		int feet = (int)distance / 12;
		int inches = (int)distance % 12; 
		String answer = (feet +" foot " + inches + " inches");
		return answer;
	}
	
	/** Method used for calculating millilitres to fluid ounces
	 * @param volume of type double
	 * @return calculated volume
	 */
	public double mlToOz(double volume) {
		return volume * 0.033814;
	}
	
	/** Method used for calculating celcius to farenheit
	 * @param temp of type double
	 * @return calculated temperature
	 */
	public double celToFaren(double temp) {
		return (temp * 9/5 + 32);
	}
	
	/** Method used for calculating litres to gallons
	 * @param volume of type double
	 * @return calculated volume
	 */
	public double litreToGallon(double volume) {
		return volume* 0.264172;
	}
	
	/** Method used for calculating centimetres to inches
	 * @param distance of type double
	 * @return calculated length
	 */
	public double centToInch(double distance) {
		return distance * 0.393701;
	}
	
	/** Method used for calculating litres to pints
	 * @param volume of type double
	 * @return calculated volume
	 */
	public double litreToPint(double volume) {
		return volume * 2.11338;
	}
}
