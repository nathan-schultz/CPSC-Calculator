
public class MathFunctions {
	
	/** Method used for calculating multiplication of two numbers
	 * @param num1 of type double
	 * @param num2 of type double
	 * @return calculated number
	 */
	public double mult(double num1, double num2) {
		return num1 * num2;
	}
	
	/** Method used for calculating addition of two numbers
	 * @param num1 of type double
	 * @param num2 of type double
	 * @return calculated number
	 */
	public double add(double num1, double num2) {
		return num1 + num2;
	}
	
	/** Method used for calculating division of two numbers
	 * @param num1 of type double
	 * @param num2 of type double
	 * @return calculated number
	 */
	public double divide(double num1, double num2) {
		return num1 / num2;
	}
	
	/** Method used for calculating subtraction of two numbers
	 * @param num1 of type double
	 * @param num2 of type double
	 * @return calculated number
	 */
	public double subt(double num1, double num2) {
		return num1 - num2;
	}
}
